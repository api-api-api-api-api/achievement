<?php
defined('BASEPATH') or exit('No direct script access allowed');
setlocale(LC_ALL, 'IND');
class Menu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logout();
        $this->user = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $this->load->model('Menu_model', 'model');
    }

    public function index()
    {
        $data = [
            'judul' => $this->session->userdata('nama_divisi'),
            'user' => $this->user
        ];

        $this->templating->load('menu/index', $data);
    }

    public function read_data_manager()
    {
        if ($this->input->is_ajax_request() == true) {
            $list = $this->model->get_datatables_manager();
            $data = [];
            $no = $_POST['start'];
            foreach ($list as $field) {

                $no++;
                $row = [];

                $btnAction = "<button type=\"button\" data-toggle=\"modal\" data-target=\"#detail-achievement\" class='btn text-white btn-sm bg-gradient-info btn-hapus' data-id=\"$field->id\" data-tgl=\"" . strftime('%A, %d %B %Y', strtotime($field->tanggal)) . "\" data-instansi=\"$field->nama\" data-isi=\"$field->keterangan\"><i class=\"fas fa-fw fa-eye\"></i> Detail</button>";

                $row[] = $no;
                $row[] = strftime('%A, %d %B %Y', strtotime($field->tanggal));
                $row[] = $field->nama;
               
                $row[] = $btnAction;
                $data[] = $row;
            }

            $output = [
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->model->count_all_manager(),
                "recordsFiltered" => $this->model->count_filtered_manager(),
                "data" => $data,
            ];
            echo json_encode($output);
        } else {
            exit('Maaf data tidak bisa ditampilkan');
        }
    }

    public function read_data()
    {
        if ($this->input->is_ajax_request() == true) {
            $list = $this->model->get_datatables();
            $data = [];
            $no = $_POST['start'];
            foreach ($list as $field) {

                $no++;
                $row = [];

                $btnAction = "<button type=\"button\" data-toggle=\"modal\" data-target=\"#detail-achievement\" class='btn text-white btn-sm bg-gradient-info btn-hapus' data-id=\"$field->id\" data-tgl=\"" . strftime('%A, %d %B %Y', strtotime($field->tanggal)) . "\" data-instansi=\"$field->nama\" data-isi=\"$field->keterangan\"><i class=\"fas fa-fw fa-eye\"></i> Detail</button>";

                $row[] = $no;
                $row[] = strftime('%A, %d %B %Y', strtotime($field->tanggal));
                $row[] = $field->nama;
               
                $row[] = $btnAction;
                $data[] = $row;
            }

            $output = [
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->model->count_all(),
                "recordsFiltered" => $this->model->count_filtered(),
                "data" => $data,
            ];
            echo json_encode($output);
        } else {
            exit('Maaf data tidak bisa ditampilkan');
        }
    }

    public function read_data_user()
    {
        if ($this->input->is_ajax_request() == true) {
            $list = $this->model->get_datatables_user();
            $data = [];
            $no = $_POST['start'];
            foreach ($list as $field) {

                $row = [];

                $btnAction = "<button type=\"button\" data-toggle=\"modal\" data-target=\"#detail-achievement\" class='btn text-white btn-sm bg-gradient-info btn-hapus' data-id=\"$field->id\" data-tgl=\"" . strftime('%A, %d %B %Y', strtotime($field->tanggal)) . "\" data-instansi=\"$field->nama\" data-isi=\"$field->keterangan\"><i class=\"fas fa-fw fa-edit\"></i>Edit</button>
                            <button type=\"button\" data-toggle=\"modal\" data-target=\"#hapus-achievement\" class='btn text-white btn-sm bg-gradient-danger btn-hapus' data-id=\"$field->id\"><i class=\"fas fa-fw fa-trash-alt\"></i> Hapus</button>";
                
                $ket = "<textarea name=\"keterangan\" readonly class=\"form-control-plaintext\" id=\"keterangan\" cols=\"30\" rows=\"4\">$field->keterangan</textarea>";

                $row[] = strftime('%A, %d %B %Y', strtotime($field->tanggal));              
                $row[] = $ket;
                $row[] = $btnAction;
                $data[] = $row;
            }

            $output = [
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->model->count_all_user(),
                "recordsFiltered" => $this->model->count_filtered_user(),
                "data" => $data,
            ];
            //output dalam format JSON
            echo json_encode($output);
        } else {
            exit('Maaf data tidak bisa ditampilkan');
        }
    }

    public function tambah_data_aksi()
    {
        if ($this->input->is_ajax_request() == true) {
            $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
            $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
            $this->form_validation->set_rules('idtanggal', 'Tanggal ini', 'is_unique[achievement.idtanggal]');

            $this->form_validation->set_error_delimiters('', '');

            if ($this->form_validation->run() == false) {
                $errors = [
                    'tanggal' => form_error('tanggal'),
                    'keterangan' => form_error('keterangan'),
                    'keterangan' => form_error('idtanggal'),
                ];

                $data = [
                    'errors' => $errors
                ];

                $this->output->set_content_type('application/json')->set_output(json_encode($data));
            } else {
                $this->model->tambah_data();
                $data['status'] = TRUE;
                $this->output->set_content_type('application/json')->set_output(json_encode($data));
            }
        } else {
            redirect('DaftarAchievement');
        }
    }


    public function ubah_status()
    {
        $this->model->ubahStatusachievement();
    }

    public function hapus_data()
    {
        $id = $this->input->post('id');
        $this->db->where('id', $id);
        $this->db->delete('achievement');
        $this->session->set_flashdata('msg', 'dihapus.');
        redirect('DaftarAchievement');
    }

    public function laporan()
    {
        $data = [
            'judul' => 'Laporan',
            'user' => $this->user,
            'namauser' => $this->model->getNamaUser(),
            'divisi' => $this->model->getNamaDivisi()
        ];

        $this->templating->load('report/index', $data);
    }

    public function cetak_laporan()
    { 
        if (isset($_POST['btn-cek'])) {
            $mulai = $this->input->post('tgl_mulai');
            $selesai = $this->input->post('tgl_selesai');
            $user = $this->input->post('namauser');
            $divisi = $this->input->post('divisi');

            $data = [
                'judul' => 'Laporan',
                'user' => $this->user,
                'namauser' => $this->model->getNamaUser(),
                'divisi' => $this->model->getNamaDivisi(),
                'data' => $this->model->getachievementByDate($mulai, $selesai, $user, $divisi)
            ];

            $this->templating->load('report/index', $data);

        } else if (isset($_POST['cetak-pdf'])) {
            $mulai = $this->input->post('tgl_mulai');
            $selesai = $this->input->post('tgl_selesai');
            $user = $this->input->post('namauser');
            $divisi = $this->input->post('divisi');

            $this->load->library('dompdf_gen');

            $data = [
                'data' => $this->model->getachievementByDate($mulai, $selesai, $user, $divisi)
            ];

            $this->load->view('report/laporan_pdf', $data);

            $paper_size = 'A4';
            $orientation = 'landscape';
            $html = $this->output->get_output();
            $this->dompdf->set_paper($paper_size, $orientation);

            $this->dompdf->load_html($html);
            $this->dompdf->render();
            $this->dompdf->stream('Laporan achievement Jaringan.pdf', ['Attachment' => true]); 

            exit;
        } else {
            redirect('laporan-achievement');
        }
    }
}
